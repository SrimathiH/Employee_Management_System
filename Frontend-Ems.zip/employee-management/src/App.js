import React, { useState, useEffect } from 'react';
import axios from 'axios';
import EmployeeForm from './components/EmployeeForm';
import EmployeeList from './components/EmployeeList';
import './App.css';

const App = () => {
  const [employees, setEmployees] = useState([]);
  const [employeeToEdit, setEmployeeToEdit] = useState(null);

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      const response = await axios.get('http://localhost:8080/employees');
      setEmployees(response.data);
    } catch (error) {
      alert('Error fetching employees.');
      console.error(error);
    }
  };

  const handleAddOrUpdate = async (employee) => {
    try {
      if (employee.id) {
        await axios.put(`http://localhost:8080/employees/${employee.id}`, employee);
      } else {
        await axios.post('http://localhost:8080/employees', employee);
      }
      fetchEmployees(); // Refresh employee list
    } catch (error) {
      alert('Error saving employee.');
      console.error(error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:8080/employees/${id}`);
      fetchEmployees(); // Refresh employee list
    } catch (error) {
      alert('Error deleting employee.');
      console.error(error);
    }
  };

  return (
    <div className="app">
      <h1>Employee Management System</h1>
      <EmployeeForm
        employeeToEdit={employeeToEdit}
        onSave={handleAddOrUpdate}
        onCancel={() => setEmployeeToEdit(null)}
      />
      <EmployeeList
        employees={employees}
        onEdit={(employee) => setEmployeeToEdit(employee)}
        onDelete={handleDelete}
      />
    </div>
  );
};

export default App;
