import React, { useState, useEffect } from 'react';
import './EmployeeForm.css';

const EmployeeForm = ({ employeeToEdit, onSave, onCancel }) => {
  const [employee, setEmployee] = useState({ name: '', role: '', salary: '' });

  useEffect(() => {
    if (employeeToEdit) {
      setEmployee(employeeToEdit);
    } else {
      setEmployee({ name: '', role: '', salary: '' });
    }
  }, [employeeToEdit]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(employee);
    setEmployee({ name: '', role: '', salary: '' }); // Clear form
    onCancel();
  };

  return (
    <form className="employee-form" onSubmit={handleSubmit}>
      <h2>{employeeToEdit ? 'Edit Employee' : 'Add Employee'}</h2>  
    {/* ternary operator */}
      <input
        type="text"
        placeholder="Name"
        value={employee.name}
        onChange={(e) => setEmployee({ ...employee, name: e.target.value })}
        required
      />
      <input
        type="text"
        placeholder="Role"
        value={employee.role}
        onChange={(e) => setEmployee({ ...employee, role: e.target.value })}
        required
      />
      <input
        type="number"
        placeholder="Salary"
        value={employee.salary}
        onChange={(e) => setEmployee({ ...employee, salary: e.target.value })}
        required
      />
      <button type="submit">{employeeToEdit ? 'Update' : 'Add'}</button>
      {employeeToEdit && <button onClick={onCancel}>Cancel</button>}
    </form>
  );
};

export default EmployeeForm;
