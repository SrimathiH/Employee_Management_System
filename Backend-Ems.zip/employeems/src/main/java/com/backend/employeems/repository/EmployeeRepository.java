package com.backend.employeems.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.backend.employeems.model.Employee;


@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long>{


}


//COMMUNICATION BETWEEN MAVEN PROJECT AND DATABASE
//CRUD - CREATE , READ, UPDATE , DELETE

//JPA REPO - predefined interface ( managing data , primary key)
